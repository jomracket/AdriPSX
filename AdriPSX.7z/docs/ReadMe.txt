************************************************************
AdriPSX Playstation Emulator for PC
(c)2002, Roor Makurosu
AdriPSX ILE Edition, Release 1.0.5
************************************************************

This Software will not be distributed on CD-ROM (covermount
or otherwise), in a software compilation, or for a sum of
money. "AdriPSX" will not be sold in any way.
Any inclusion on media other than the Internet will require
the author written consent.

The author will in no way endorse the use of Playstation
software other than ORIGINAL Playstation CDROMS. The use
of "pirated" or "Imaged" CDROMS is strictly prohibited.
The author will not be answerable to any legal claim make
by Software vendors against an "AdriPSX" user.

The user agrees not to ask the authors questions answered in
the enclosed README file, questions about release dates,
or questions about the third party driver plugins unless
specifically asked to do so by the authors.

************************************************************


Table of Contents

1. What is AdriPSX ?
2. AdriPSX minimun requirements.
3. AdriPSX BIOS requirement.
4. Getting Started.
5. Troubleshooting.
6. Development status.
7. Greetings and credits.


************************************************************
1. What is AdriPSX ?

AdriPSX is a Sony PlayStation) (AKA known as PSX) emulator,
developed by Roor Makurosu...
It can run several games designed for the PSX console on a
PC running Windows 9x, NT, 2000 or DOS..
Its perfomance depends heavily on your PC configuration, and
what kind of PSX game you are trying to run.
AdriPSX will never substitute a true PSX but it can give you
the excitement to run your favorite games on your PC.
Many games will not work properly or not work at all.
I'm very aware of this and I'm always trying my best to make
more games work flawlessly and speed up its performance.


************************************************************
2. AdriPSX minimum requirements

Required:
* Windows 95/98/ME, NT (SP4), XP or 2000.
* DirectX Sound Compatible Hardware.
* PC 80486, Pentium, Pentium II, Pentium III, Celeron, or
 any compatible processor. (300 MHz at least are highly
 recommended).
* 16 MB of RAM at least.(32 MB are recommended).
* 10 MB of hard drive space.
* 16-bit video card (3D-Card is highly recommended).
* 8x or faster CD-ROM or desktop DVD-ROM drive.

Some laptop DVD-ROM drives are unable to read game disks.
Not all PlayStation games play well with AdriPSX, and some
may not play at all.

************************************************************
3. AdriPSX BIOS requirement

If you got to this point you have sucessfully extracted the
AdriPSX files in a directoryy. There are other directories
inside AdriPSX\. In the directory "Bios" you will have to
place a PSX BIOS ROM image. You can find the instructions on
how to download the BIOS image from your PSX and some already
downloaded BIOSes at some emulation sites. Which image to
download is up to the version of your PSX. Although, the
version named SCPH1001 is recommended.

NOTE: You are legally entitled to have an electronic
reproduction of the PSX BIOS ONLY if you personally own an
original PSX console. The BIOS image, like all commercial
software is protected under copyright law.


************************************************************
4. Getting started

So you have the BIOS image as a file. Put it in the "Bios"
directory and run the AdriILE.exe executable file.

To begin playing a game, just insert the game CD into your
CD-ROM drive, and select "Boot PSX-CD" in the AdriPSX menu,
after having all plugins and controller configured.

During game-playing there's some useful key functions like:

 -F12   Turn On/Off the Recompiler Engines.

 -F11   Resets Recompilers, and attemp to Statically
        Recompile the whole memory contents.

 -F3    Activates/Desactivates partial Memory Cards support.

 -F4    Save current Playstation State.

 -F5    Load a previously saved Playstation State.

 -ESC   Quits emulator.

************************************************************
5. Troubleshooting

- QUESTION: My favourite game doesn't work.
- ANSWER: Not all games are supported yet, try next release.
          As this one is an "experimental release", it is
          more likely that the emu has some bugs that may
          make it difficult to run certain games.
          For making X games run, you may play a little with
          setup... and get a few surprises.
          Compatibility changes a lot, when you enable or
          disable different CPU options, like DYNAREC,
          STATICREC or HLE.

- QUESTION: Emulation stops while playing an MDEC movie.
- ANSWER: MDEC timing is not perfect, because of problems
          with CD-ROM Decoder. Try setting AdriPSX for
          skipping MDEC, so to let the game work.

- QUESTION: Some sounds in the game are missing.
- ANSWER: Sometimes this happens because the SPU plugin is
          set for working as MONO, other times because the
          missing sound is CDDA, or skipped CDXA.
          AdriPSX doesn't support old style SPU plugins
          like SEAL or Kazuya's SPU.
          Also, when using some old versions of NULL'S SPU
          all CDXA MONO Sounds are missing.

- QUESTION: Can you give, or tell me where to find BIOS?
- ANSWER: Absolutely no.

- QUESTION: There are several PSX BIOS outthere...
            Which one should I use for make AdriPSX run?
- ANSWER: Use only SCPH1001.BIN.
          Because most of BIOS is being run by HLE functions
          based on SCPH1001, it is most likely that it will
          not run fine, or not run at all, when using other
          file rather than SCPH1001.BIN

- QUESTION: Everytime I try to run a game, the emulator
          display a message saying "Couldn't load X plugin."
- ANSWER: This is most likely to happen when you have not yet
          configured all Plugins. Just be sure to configure
          plugins at least once.
          Also, if you had installed a previous version of
          AdriPSX sometime in the past, it may be possible
          that an "old" configuration stored in Windows
          Registry may be causing trouble. This is fixed just
          configuring ALL plugins (including CPU setup) at
          in this new version, at least one time. Other
          option is that you can erase the ADRIPSX entry in
          Windows Registry using REGEDIT or any other tool.
          Another cause for this problem could be that the
          file ADRIPSX.INI is write-protected or corrupted,
          in this case, just erase it and configure the emu
          again.

- QUESTION: You said that AdriPSX runs under WIN2K/XP...
            But it doesn't run on mine.
- ANSWER: WIN2K compatibility problems are mostly caused by
          plugins. For fixing this, it is recommended to
          read each plugin documentation, and be sure that
          it had support for WIN2K.
          For better compatibility, you can try disabling
          sound (so no SPU plugin will be used).

- QUESTION: I can't heard CDXA music with your emu!

- ANSWER: For enabling CDXA playing, you must set CDROM
          EXTRA DECODER on (in CDROM SETUP).
          But notice that by enabling it, compatibility
          may change.

- QUESTION: In some games, I got corrupted MDECs, and even
	    some times, it seems not to be responding to
	    my controller commands....
- ANSWER: For solving this kind of problem, try just by
	  pressing F11 key on time. This will almost always
	  fix any problem of that kind.

************************************************************
6. Development Status

  Lots of improvements has been done since previous release,
as well as several bugs corrected. But anyway, compatibility
has changed a lots... several games that used to work fine,
do not work at all now... but others that weren't working now
run fine.

  The author plans to make updates more frequently now, so
compatibility will increase soon, with every new release.

************************************************************
7. Credits.

AdriPSX is the work of the following people:

  Roor Makurosu : Main coder, developer, researcher, etc.
  h_y_a@yahoo.com
  adripsx@psxemu.com

  Juan Fazzini : Helper coder, GUI designer.
  juan@psxemu.com
  